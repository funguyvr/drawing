const canvas = document.getElementById('drawingCanvas');
const ctx = canvas.getContext('2d');
const colorPicker = document.getElementById('colorPicker');
const brushSize = document.getElementById('brushSize');
const shapeSelector = document.getElementById('shapeSelector'); // Shape selector
const rotationAngle = document.getElementById('rotationAngle'); // Rotation input
const clearButton = document.getElementById('clearButton');
const undoButton = document.getElementById('undoButton');
const redoButton = document.getElementById('redoButton');
const saveButton = document.getElementById('saveButton');

// Set canvas size
canvas.width = window.innerWidth * 0.8;
canvas.height = window.innerHeight * 0.6;

let drawing = false;
let startX, startY;
let undoStack = [];
let redoStack = [];
let selectedShape = 'free'; // Default shape is free drawing

// Track selected shape
shapeSelector.addEventListener('change', (e) => {
    selectedShape = e.target.value;
});

function saveState() {
    undoStack.push(canvas.toDataURL()); // Save canvas state to undo stack
    redoStack = []; // Clear the redo stack whenever a new action is performed
}

function restoreState(stack) {
    const canvasImage = new Image();
    const state = stack.pop();
    if (state) {
        canvasImage.src = state;
        canvasImage.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear current canvas
            ctx.drawImage(canvasImage, 0, 0); // Draw the saved state
        };
    }
}

function startDrawing(e) {
    drawing = true;
    startX = e.clientX - canvas.offsetLeft;
    startY = e.clientY - canvas.offsetTop;
    saveState(); // Save the state before starting a new drawing
}

function endDrawing(e) {
    drawing = false;
    ctx.beginPath(); // Ends the current path

    if (selectedShape !== 'free') {
        // Draw the final shape when the mouse is released
        const endX = e.clientX - canvas.offsetLeft;
        const endY = e.clientY - canvas.offsetTop;
        drawShape(startX, startY, endX, endY);
    }
}

function draw(e) {
    if (!drawing) return;

    const currentX = e.clientX - canvas.offsetLeft;
    const currentY = e.clientY - canvas.offsetTop;

    if (selectedShape === 'free') {
        // Freehand drawing
        ctx.lineWidth = brushSize.value;
        ctx.lineCap = 'round';
        ctx.strokeStyle = colorPicker.value;

        ctx.lineTo(currentX, currentY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(currentX, currentY);
    }
}

function drawShape(startX, startY, endX, endY) {
    const angleInDegrees = parseFloat(rotationAngle.value); // Get the rotation angle from input
    const angleInRadians = angleInDegrees * (Math.PI / 180); // Convert degrees to radians

    ctx.lineWidth = brushSize.value;
    ctx.strokeStyle = colorPicker.value;
    ctx.save(); // Save the current state of the canvas

    // Move to the center of the shape to rotate around the center
    const centerX = (startX + endX) / 2;
    const centerY = (startY + endY) / 2;
    ctx.translate(centerX, centerY);
    ctx.rotate(angleInRadians); // Rotate the canvas by the specified angle

    ctx.beginPath();
    switch (selectedShape) {
        case 'line':
            ctx.moveTo(startX - centerX, startY - centerY); // Subtract center to ensure rotation around center
            ctx.lineTo(endX - centerX, endY - centerY);
            break;

        case 'rectangle':
            const width = endX - startX;
            const height = endY - startY;
            ctx.rect(-width / 2, -height / 2, width, height); // Draw rectangle around center
            break;

        case 'circle':
            const radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
            ctx.arc(0, 0, radius, 0, 2 * Math.PI); // Circle is centered on (0, 0) because of the translate
            break;
    }

    ctx.stroke();
    ctx.closePath();
    ctx.restore(); // Restore the canvas state (remove the rotation and translation)
}

// Event listeners for drawing
canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mouseup', endDrawing);
canvas.addEventListener('mousemove', draw);

// Clear button functionality
clearButton.addEventListener('click', () => {
    saveState(); // Save state before clearing the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
});

// Undo button functionality
undoButton.addEventListener('click', () => {
    if (undoStack.length > 0) {
        redoStack.push(canvas.toDataURL()); // Save the current state to the redo stack
        restoreState(undoStack);
    }
});

// Redo button functionality
redoButton.addEventListener('click', () => {
    if (redoStack.length > 0) {
        undoStack.push(canvas.toDataURL()); // Save the current state to the undo stack
        restoreState(redoStack);
    }
});

// Save button functionality
saveButton.addEventListener('click', () => {
    const imageData = canvas.toDataURL('image/png'); // Get the canvas as a data URL
    const link = document.createElement('a'); // Create a temporary <a> element
    link.href = imageData; // Set the href to the data URL
    link.download = 'drawing.png'; // Set the download attribute to save the file
    link.click(); // Trigger the download
});
